using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class animasyon : MonoBehaviour
{
    private Animator animation;

    void Start()
    {
        animation = GetComponent<Animator>();
    }
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Space))
        {
            animation.SetTrigger("diger_animasyon");
        }
    }
}