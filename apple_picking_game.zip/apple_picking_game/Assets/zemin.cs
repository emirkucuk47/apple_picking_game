using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class zemin : MonoBehaviour
{
    float toplamcan = 100.0f;
    float simdikican = 100.0f;
    public Image cancubugu;
    public GameObject oyunbitti;

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "elma")
        {
            Destroy(collision.gameObject);
            simdikican -= 10.0f;
            cancubugu.fillAmount = simdikican / toplamcan;
            if(simdikican<=0)
            {
                oyunbitti.SetActive(true);
                Time.timeScale = 0.0f;
            }
        }
    }
}