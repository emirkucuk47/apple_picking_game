using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class yonetici : MonoBehaviour
{
    public GameObject oyunduraklatıldı;

    public void yenidenbaslabutonu()
    {
        SceneManager.LoadScene("Scenes/elmaoyunu");
        Time.timeScale = 1f;
    }

    public void devambutonu()
    {
        oyunduraklatıldı.SetActive(false);
        Time.timeScale = 1f;
    }

    public void duraklatbutonu()
    {
        oyunduraklatıldı.SetActive(true);
        Time.timeScale = 0f;
    }

    public void çıkışbutonu()
    {
        Application.Quit();
        Debug.Log("Oyundan çıktınız.");
    }

    public GameObject elma;
    //private int saniye=10;
    void elmaekleme()
    {
        float menzil = Random.Range(0.5f, 11.5f);
        GameObject yenielma = Instantiate(elma,new Vector3(menzil,12,-6.4f),Quaternion.identity);
    }
    private void Start()
    {
        //InvokeRepeating("saniyeazaltma",0.0f,1.0f);
        InvokeRepeating("elmaekleme",0.0f,0.7f);
    }
    /*void saniyeazaltma()
    {
        saniye--;
        Debug.Log(saniye.ToString());
        if(saniye==0)
        {
            CancelInvoke("saniyeazaltma");
        }
    }*/
}