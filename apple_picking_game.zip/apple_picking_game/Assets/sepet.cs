using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class sepet : MonoBehaviour
{
    public int puan = 0;
    public float speed;
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag=="elma")
        {
            puan += 10;
            //Debug.Log(puan.ToString());
            puantxt.text =puan.ToString();
            Destroy(collision.gameObject);
        }
    }

    public TextMeshProUGUI puantxt;

    void Start()
    {
        puantxt = GameObject.Find("Canvas/puantxt").GetComponent<TextMeshProUGUI>();
    }



    void Update()
    {
        if(Input.GetKey(KeyCode.RightArrow))
        {
            transform.Translate(speed * Time.deltaTime, 0, 0);
        }

        if(Input.GetKey(KeyCode.LeftArrow))
        {
            transform.Translate(-speed * Time.deltaTime, 0, 0);
        }


    }
}